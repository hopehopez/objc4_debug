void bar() {}

void foo() __attribute__((weak));
void foo()
{
}