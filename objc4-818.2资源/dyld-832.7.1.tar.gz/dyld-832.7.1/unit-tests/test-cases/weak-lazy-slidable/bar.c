

#include <stdbool.h> 

bool bar1()
{
	return true;
}

__attribute__((weak)) void junk()
{
}
