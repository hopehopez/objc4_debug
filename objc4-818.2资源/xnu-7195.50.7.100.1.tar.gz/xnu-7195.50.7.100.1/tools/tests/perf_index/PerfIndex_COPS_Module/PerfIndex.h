//
//  PerfIndex.h
//  PerfIndex
//
//  Created by Mark Hamilton on 8/20/13.
//
//

@protocol HGTest <NSObject>

- (BOOL)execute;

@end
